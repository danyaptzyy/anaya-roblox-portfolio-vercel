module.exports = function handler(req, res) {
  return res.status(200).json({
    ok: true,
    service: "anaya-roblox-portfolio",
    status: "healthy",
    timestamp: new Date().toISOString()
  });
};
